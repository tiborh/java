The software libraries:

core-2.3-SNAPSHOT.jar
javase-2.3-SNAPSHOT.jar
tess4j.jar

are protected by the Apache License 2.0.

---------------------------------------

The software library:

jna.jar

is protected by the GNU Lesser General Public License Versoin 2.1.

---------------------------------------

The software library:

ghost4j-0.3.1.jar

is protected by the GNU Lesser General Public License Versoin 3.

---------------------------------------

The software library:

junit-4.10.jar

is prorected by the Eclipse Public License - v 1.0.

---------------------------------------

The software library:

jai_imageio.jar

is protected by the Sun Microsystems, Inc. SOFTWARE LICENSE AGREEMENT.
