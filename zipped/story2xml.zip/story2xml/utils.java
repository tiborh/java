import java.util.*;
import java.nio.file.*;
/**
 * Common utilities
 * 
 * @author tibor 
 * @version 0.01
 */
public class utils
{
    public static boolean validate_path(Path in_path)
    {
        if (Files.notExists(in_path))
        {
            System.err.format("File '%s' does not exist.%n",in_path);
            return false;
        }
        if (!Files.notExists(in_path) && !Files.exists(in_path))
        {
            System.err.format("No access to file '%s'.%n",in_path);
            return false;
        }
        return true;
    }
    
    public static void print_array(String[] in)
    {
        if (in.length == 0)
            System.out.println("<Empty array.>");
        else
            for (String a_line : in)
                System.out.println(a_line);
    }
    
    public static void print_list(Collection<String> a_list)
    {
        if (a_list.isEmpty())
            System.out.println("<Empty list.>");
        else
            for (String an_item : a_list)
                System.out.println(an_item);
    }
    
}
