import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
//import static java.nio.file.FileVisitResult.*;
//import static java.nio.file.FileVisitOption.*;
import java.util.*;
import java.nio.charset.Charset;

/**
 * class written to work with a path and get its content
 * 
 * @author tibor
 * @version 0.01
 */
public class content_list
{
    private Path file_path;
    private List<String> file_content;
    private int file_content_size;
    
    public content_list(String in_str)
    {
        file_path = str2path(in_str);
        read_file_content();
    }
    
    public content_list(Path in_path)
    {
        file_path = in_path;
        read_file_content();
    }
        
    private Path str2path(String dir_string)
    {
        Path temp_path = Paths.get(dir_string);
        if (utils.validate_path(temp_path))
            return temp_path;
        else
            return null;
    }
    
    private void read_file_content()
    {
        try
        {
            file_content = Files.readAllLines(file_path,constants.encoding);
            if (!file_content.isEmpty())
            {
                file_content_size = file_content.size();
            } else
                constants.logger.warning("Empty file: " + file_path + "\n");
        } catch (IOException e)
        {
            System.err.format("File '%s' cannot be opened for reading.%n",file_path);
            e.printStackTrace();
        }
    }
    
    public List<String> get_file_content()
    {
        if (file_content == null)
            System.err.format("File '%s' is empty.%n",file_path);
        return file_content;
    }
    
    public int get_file_content_size()
    {
        if (file_content == null)
        {
            System.err.format("File '%s' is empty.%n",file_path);
            return 0;
        }
        return file_content_size;
    }
        
    public static void main (String[] argv)
    {
        finden ein_finden = new finden(constants.test_path,constants.test_pattern1);
        Path test_path = ein_finden.get_a_path();
        System.out.format("The first path:%n\t%s%n",test_path);
        content_list test_cont = new content_list(test_path);
        //System.out.println(Arrays.toString(test_cont.get_file_content()));
        utils.print_list(test_cont.get_file_content());
    }
    
}
