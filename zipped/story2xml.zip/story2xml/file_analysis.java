import java.util.*;
import java.nio.file.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 * to process story-file in array
 * 
 * @author tibor 
 * @version 0.01
 */
public class file_analysis
{
    // good with contains
    //private Set<String> first_words = new HashSet<>();
    //private Set<String> leftover_words = new HashSet<>();
    private boolean log_on = true;
    private SortedSet<String> sorted_first_words = new TreeSet<>();
    private SortedSet<String> sorted_leftover_words = new TreeSet<>();
    private List<Path> files_ready = new LinkedList<>();
    private static final String[] reserved_words = 
    {
        "!--", //comment
        "@", // meta-element
        "After",
        "And", // step item
        "AsA", // in narrative
        "Before",
        "Description", //free text
        "Examples", // usually a table follows
        "Given", // prerequisite, step starting
        "GivenStories", // stories to be run before
        "IWantTo", // in narrative
        "InOrderTo", // in narrative
        "Lifecycle", //
        "Meta", //has meta-elements
        "Narrative", //intro <p>?
        "Outcome",
        "Scenario",
        "SoThat", // in narrative
        "Story", // consists of: Description, Meta, Narrative, GivenStorise, Lifecycle, Scenario
        "Then", // outcome of event, step starting
        "Title",
        "When", // the event, step starting
        "|" //table column
    };
    //analytics:
    private List<Path> files_to_fix = new LinkedList<>();
    private List<Path> files_no_keyword = new LinkedList<>();
    private List<Path> files_too_many_problems = new LinkedList<>();
    private List<Path> manual_tests = new LinkedList<>();
    private List<Path> table_problems = new LinkedList<>();
    
    public void reset_data()
    {
        files_to_fix = new LinkedList<>();
        files_no_keyword = new LinkedList<>();
        files_too_many_problems = new LinkedList<>();
        manual_tests = new LinkedList<>();
        table_problems = new LinkedList<>();
        sorted_first_words = new TreeSet<>();
        sorted_leftover_words = new TreeSet<>();
        files_ready = new LinkedList<>();
    }
    
    public boolean is_in_reserved(String searched)
    {
        if (Arrays.binarySearch(reserved_words,searched) >= 0)
            return true;
        return false;
    }
    
    public List<Path> get_files_ready()
    {
        return files_ready;
    }
    
    public void set_log(boolean to_log)
    {
        log_on = to_log;
    }
    
    /**
     * to test Arrays.binarySearch(where,what)
     * @param searched the string snippet to look for
     * @return if found the index where the elem is, if minus it was not found
     */
    public int array_search(String searched)
    {
        return Arrays.binarySearch(reserved_words,searched);
    }
    
    public void analyse_file_list()
    {
        reset_data();
        //get story file paths
        finden ein_finden = new finden(constants.test_path,constants.test_pattern1);
        //get the first path
        Path test_path = ein_finden.get_a_path();
        
        while(test_path != null)
        {
            final Pattern manual_test_path_pattern = Pattern.compile(".*Manual_Tests.*");
            if (manual_test_path_pattern.matcher(test_path.toString()).matches())
            {
                manual_tests.add(test_path);
                //constants.logger.info("Manual Test file: " + test_path + "\n");
                test_path = ein_finden.get_a_path();
                continue;
            }
            analyse_path(test_path);
            test_path = ein_finden.get_a_path();
        }
    }
    
    public void analyse_path (Path test_path)
    {
        //get the content of the file of the first path
        content_list test_cont = new content_list(test_path);
        // get the above content into an array
        List<String> test_list = test_cont.get_file_content();
        final Pattern empty_line_pattern = Pattern.compile("\\A\\s*\\z");
        if (test_list != null)
        {
            int key_word_counter = 0;
            int error_counter = 0;
            int table_problem_counter = 0;
            String log_string = "";
            constants.logger.fine("Parsing file:\n\t" + test_path + "\n");
            for (String test_line : test_list)
            {

                if (!empty_line_pattern.matcher(test_line).matches())
                {
                    String a_word = test_line.split("\\s")[0];
                    if (is_in_reserved(a_word))
                    {
                        sorted_first_words.add(a_word);
                        key_word_counter++;
                    } else if (first_word_start_check(a_word))
                    {
                        key_word_counter++;
                        // do nothing else, the method does the adding 
                        //first_words.add(a_word);
                        //sorted_first_words.add(a_word);
                    } else if (test_line.contains("|"))
                    {
                        // | needs to be provided to the front of the line
                        table_problem_counter++;
                    } else
                    {
                        //leftover_words.add(a_word);
                        sorted_leftover_words.add(a_word);
                        log_string += "leftover word: '" + a_word + "'\n\tin line:\n\t'" + test_line + "\n";
                        error_counter++;
                    }
                }
            }
            if (key_word_counter == 0)
            {
                constants.logger.warning("No key words in file, so it will not be included:\n\t"
                    + test_path + "\n");
                files_no_keyword.add(test_path);
            } else if (error_counter >= constants.MAX_ERROR_COUNT)
            {
                constants.logger.warning("There are more than " + constants.MAX_ERROR_COUNT 
                    + " problems in file\n\t: " + test_path + "\n So it will NOT be included.\n");
                files_too_many_problems.add(test_path);
            } else if (!log_string.equals(""))
            {
                if (log_on)
                    constants.logger.info("In file: " + test_path + "\n" + log_string);
                files_to_fix.add(test_path);
            } else
            {
                files_ready.add(test_path);
            }
            if (table_problem_counter > 0)
            {
                table_problems.add(test_path);
            }
            constants.logger.fine("Finished parsing file:\n\t" + test_path + "\n");
        }
    }
    
    public void print_results()
    {
        System.err.println("The following files may be worth fixing:\n");
        print_list(files_to_fix);
        System.err.println("The following files have too many problems:\n");
        print_list(files_too_many_problems);
        System.err.println("The following do not seem to be real story files:\n");
        print_list(files_no_keyword);
        System.err.println("Manual test files (not processed):\n");
        print_list(manual_tests);
        System.err.println("Table problems (opening bar may be missing):\n");
        print_list(table_problems);
        System.err.format("=====\nThe number of files ready to parse: %d%n",files_ready.size());
    }
    
    private void print_list(Collection<Path> a_list)
    {
        if (a_list == null)
            System.err.println("Empty list.");
        else
        {
            for (Path an_item : a_list)
                System.err.println(an_item);
            System.err.println("-----");
            System.err.format("Number of files: %d%n",a_list.size());
            System.err.println();
        }
    }

    
    public boolean first_word_start_check(String a_word)
    {
        for (String a_reserved : reserved_words)
            if (a_word.startsWith(a_reserved))
            {
                //first_words.add(a_reserved);
                sorted_first_words.add(a_reserved);
                return true;
            }
        return false;
    }
    
    /*
    public void print_first_words()
    {
        utils.print_list(first_words);
    }
    */
    
    public void print_sorted_first_words()
    {
        utils.print_list(sorted_first_words);
    }
    
    /*
    public void print_leftover_words()
    {
        utils.print_list(leftover_words);
    }
    */

    public void print_sorted_leftover_words()
    {
        utils.print_list(sorted_leftover_words);
    }

    public static void main(String[] argv)
    {
        file_analysis a_test = new file_analysis();
        a_test.analyse_file_list();
        System.out.println("First words from 'reserved words' list:");
        a_test.print_sorted_first_words();
        System.out.println("\nFirst words not on the list:");
        a_test.print_sorted_leftover_words();
        a_test.print_results();
    }
}
