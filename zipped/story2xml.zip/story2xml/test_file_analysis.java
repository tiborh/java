import java.util.*;
import java.nio.file.*;
/**
 * Write a description of class file_list_analysis here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class test_file_analysis extends file_analysis
{   
    public void analyse_file_list()
    {
        super.reset_data();
        file_analysis a_test = new file_analysis();
        a_test.set_log(false);
        a_test.analyse_file_list();
        List<Path> files_to_check = a_test.get_files_ready();
        
        for (Path a_path : files_to_check)
            super.analyse_path(a_path);
    }

    public static void main(String[] argv)
    {
        test_file_analysis a_test = new test_file_analysis();
        a_test.analyse_file_list();
        System.out.println("First words from 'reserved words' list:");
        a_test.print_sorted_first_words();
        System.out.println("\nFirst words not on the list:");
        a_test.print_sorted_leftover_words();
        a_test.print_results();
    }
}
