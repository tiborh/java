/**
 * find class adapted from
 * http://docs.oracle.com/javase/tutorial/essential/io/find.html
 * 
 * @author Oracle, modified by tibor
 * @version 0.01
 */
/**
 * Sample code that finds files that match the specified glob pattern.
 * For more information on what constitutes a glob pattern, see
 * http://docs.oracle.com/javase/tutorial/essential/io/fileOps.html#glob
 *
 * The file or directories that match the pattern are printed to
 * standard out.  The number of matches is also printed.
 *
 * When executing this application, you must put the glob pattern
 * in quotes, so the shell will not expand any wild cards:
 *              java Find . -name "*.java"
 */

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import static java.nio.file.FileVisitResult.*;
import static java.nio.file.FileVisitOption.*;
import java.util.*;

public class finden
{
    //private final static int MAX_ARRAY_SIZE = 1024;
    private int array_counter;
    private Path[] file_list;
    private Path starting_dir;
    private String search_pattern;
    private int nu_of_matches;
    private int get_counter;
    
    public finden()
    {
        this(".","*");
    }
    
    public finden(String dir_string, String a_pattern)
    {
        array_counter = 0;
        nu_of_matches = 0;
        get_counter = 0;
        file_list = new Path[constants.MAX_ARRAY_SIZE];
        set_start_dir(dir_string);
        set_search_pattern(a_pattern);
        make_search();
    }
        
    private void set_start_dir(String dir_string)
    {
        Path temp_dir = Paths.get(dir_string);
        if (utils.validate_path(temp_dir))
            starting_dir = temp_dir;
    }
    
    public Path get_a_path()
    {
        if (get_counter < nu_of_matches)
            return file_list[get_counter++];
        else
            return null;
    }
    
    public void reset_get_counter()
    {
        get_counter = 0;
    }
    
    public int get_nu_of_matches()
    {
        return nu_of_matches;
    }
    
    private void set_search_pattern(String pattern_string)
    {
        search_pattern = pattern_string;
    }
    
    private void add_line_to_list(Path a_file)
    {
        if (array_counter >= constants.MAX_ARRAY_SIZE)
        {
            System.out.format("Array max size (%d) has been reached.%n",constants.MAX_ARRAY_SIZE);
            System.out.format("Last element in the list:%n%s%nExiting...%n",
                print_list_element(array_counter - 1));
            System.exit(1);
        }
        file_list[array_counter] = a_file;
        array_counter++;
    }
    
    private void make_search()
    {
        Finder finder = new Finder(search_pattern);
        try
        {
            Files.walkFileTree(starting_dir, finder);
        }
        catch(java.io.IOException e)
        {
            System.err.println("Cannot read the directory tree.");
            e.printStackTrace();
            System.exit(1);
        }
        finder.done();
    }
    
    public void print_list()
    {
        if (array_counter == 0)
            System.out.println("Empty list");
        else
            for (int i = 0; i < array_counter; i++)
                System.out.println(file_list[i]);
    }
    
    public String print_list_element(int index)
    {
        if (index >= array_counter)
        {
            System.err.println("Index is out of range.");
            return "";
        }
        return file_list[index].toString();
    }
    
    public class Finder extends SimpleFileVisitor<Path>
    {
        private final PathMatcher matcher;
        private int numMatches;

        Finder(String pattern) {
            numMatches = 0;
            matcher = FileSystems.getDefault()
                    .getPathMatcher("glob:" + pattern);
        }

        // Compares the glob pattern against
        // the file or directory name.
        void find(Path file) {
            Path name = file.getFileName();
            if (name != null && matcher.matches(name)) {
                numMatches++;
                add_line_to_list(file);
            }
        }
        
        // Prints the total number of
        // matches to standard out.
        void done() {
            nu_of_matches = numMatches;
        }

        // Invoke the pattern matching
        // method on each file.
        @Override
        public FileVisitResult visitFile(Path file,
                BasicFileAttributes attrs) {
            find(file);
            return CONTINUE;
        }

        // Invoke the pattern matching
        // method on each directory.
        @Override
        public FileVisitResult preVisitDirectory(Path dir,
                BasicFileAttributes attrs) {
            find(dir);
            return CONTINUE;
        }

        @Override
        public FileVisitResult visitFileFailed(Path file,
                IOException exc) {
            System.err.println(exc);
            return CONTINUE;
        }
    }

    static void usage() {
        System.err.println("java Find <path>" +
            " -name \"<glob_pattern>\"");
        System.exit(-1);
    }

    public static void main(String[] args)
        throws IOException {

        if (args.length < 3 || !args[1].equals("-name"))
            usage();

        finden ein_finden = new finden(args[0],args[2]);
        ein_finden.print_list();
        System.out.format("Number of matches: %d%n",ein_finden.get_nu_of_matches());
    }
}