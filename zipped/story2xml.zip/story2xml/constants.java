import java.nio.charset.Charset;
import java.util.logging.*;
/**
 * Only constants are stored here.
 * 
 * @author tibor
 * @version 0.01
 */
public class constants
{
   //public static final String test_path = "../invtest";
   public static final String test_path = "../../work/invtest";
   public static final String test_pattern1 = "*.story";
   public static final Charset encoding = Charset.defaultCharset();
   public static final int MAX_ARRAY_SIZE = 1024;
   public static final Logger logger = Logger.getLogger("net.harcsa.story2xml");
   public static final int LOG_ROTATION_COUNT = 10;
   public static final int MAX_ERROR_COUNT = 10;
}
