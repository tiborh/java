import java.io.*;
import java.util.*;
import java.nio.file.*;
/**
 * copy the test files into a directory and correct known problems.
 * 
 * @author tibor
 * @version 0.01
 */
public class copy_ready_files
{
    private List<Path> files_to_process;
    
    public void fill_path_list()
    {
        file_analysis a_test = new file_analysis();
        a_test.set_log(false);
        a_test.analyse_file_list();
        files_to_process = a_test.get_files_ready();
    }
    
    public void create_dir(String dir_str)
    {
        Path dir_path = Paths.get(dir_str);
        if (Files.notExists(dir_path))
        {
            try
            {
                Files.createDirectory(dir_path);
            } catch (IOException e)
            {
                System.err.format("Directory '%s' cannot be created%n",dir_path);
                e.printStackTrace();
                System.exit(1);
            }
        }
    }
    
    public void empty_directory(String dir_str)
    {
        Path dir_path = Paths.get(dir_str);
        Path files_to_delete = Paths.get("*.story");
        Path target_path = dir_path.resolve(files_to_delete);
        if (Files.exists(dir_path) && Files.isWritable(dir_path) && Files.isExecutable(dir_path))
        {
            try {
                    Files.delete(target_path);
                } catch (NoSuchFileException x) {
                    System.err.format("%s: no such" + " file or directory%n", target_path);
                } catch (DirectoryNotEmptyException x) {
                    System.err.format("%s not empty%n", target_path);
                } catch (IOException x) {
                    // File permission problems are caught here.
                    System.err.println(x);
                    System.exit(1);
                }
        }
            
    }
}
