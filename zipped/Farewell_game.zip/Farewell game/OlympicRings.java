import comp102x.ColorImage;
import comp102x.Canvas;
import comp102x.IO;

import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class OlympicRings implements MouseListener, MouseMotionListener
{
    private static final int WIDTH = 1000;
    private static final int HEIGHT = 650;
    
    private static int nRings = 5;
    private static Canvas canvas = new Canvas(WIDTH, HEIGHT);
    private static ColorImage[] rings = new ColorImage[nRings]; 
    private static ColorImage[] ring0 = new ColorImage[nRings];
    private static ColorImage olympicRings = new ColorImage("images/OlympicRings.png");
    private static ColorImage arrow = new ColorImage("images/arrow.png");
    private static ColorImage background = new ColorImage(WIDTH, HEIGHT);
    private static int rWidth;
    private static int rHeight;
    private static int steps = 100;
    private static final int OX = 100;
    private static final int OY = 200;
    private static boolean[] hitStatus = new boolean[nRings];
    private static int numberOfHitRings = 0;
    private static ExecutorService threadPool = Executors.newSingleThreadExecutor();
    
    private static boolean isShooting = false;
    private static boolean isPlaying = false;
    
    private static ColorImage ball = new ColorImage("images/ustb1.png");
    private static ColorImage moocDNA = new ColorImage("images/MOOCDNA.jpg");
    /**
     * Constructor for objects of class PlacingRings
     */
    public OlympicRings()
    {
        canvas.add(background);
        
        for (int i=0; i < nRings; i++) {
            rings[i] = new ColorImage("images/ring" + (i+1) + ".png");
            rings[i].setScale(0.5);
            rings[i].setMovable(false);
            ring0[i] = new ColorImage("images/ring0.png");
            ring0[i].setScale(0.5);
            ring0[i].setMovable(false);
            canvas.add(rings[i], 50+i*200, 50);
            canvas.add(ring0[i], 50+i*200, 50);
        }
        
        arrow.setMovable(false);
        ball.setMovable(false);
        olympicRings.setMovable(false);
        moocDNA.setMovable(false);
        background.setMovable(false);

        rWidth = rings[0].getWidth();
        rHeight = rings[0].getHeight();
        
        ball.setScale(0.5);
        int ballX = WIDTH / 2 - (int)(ball.getWidth() * ball.getScale()) / 2;
        int ballY = HEIGHT - (int)(ball.getHeight() * ball.getScale()) - 50;
        
        int arrowX = WIDTH / 2 - arrow.getWidth() / 2;
        int arrowY = HEIGHT - arrow.getHeight() / 2 - (int)(ball.getHeight() * ball.getScale() / 2) - 50;
        
        canvas.add(arrow, arrowX, arrowY);
        canvas.add(ball, ballX, ballY);
        
        canvas.addMouseListener(this);
        canvas.addMouseMotionListener(this);
        
        isPlaying = true;
    }
    
    private static void displayOlympicRings(int x, int y) {
        canvas.add(olympicRings, x, y);
    }
    
    private static void moveRings(ColorImage[] rings, int[][] iXY) {
        double[] iX = new double[nRings];
        double[] iY = new double[nRings];
        double[] iS = new double[nRings];
        double[] dX = new double[nRings];
        double[] dY = new double[nRings];
        double[] dS = new double[nRings];
        
        for (int i=0; i<nRings; i++) {
            iX[i] = rings[i].getX();
            iY[i] = rings[i].getY();
            iS[i] = rings[i].getScale();
            dX[i] = ((OX + iXY[i][0] - 120) - iX[i])/steps;
            dY[i] = ((OY + iXY[i][1] - 120) - iY[i])/steps;
            dS[i] = (1 - iS[i])/steps;
        }
        
        for (int i = 1; i <= steps; i++) {
            for (int j = 0; j < nRings; j++) {
               rings[j].setScale(iS[j] + i*dS[j]);
               rings[j].setX((int) (iX[j] + i*dX[j]));
               rings[j].setY((int) (iY[j] + i*dY[j]));
            }
            pause(30);
        }
    }
    
    private static void moveBall(ColorImage ball, double angle) {
        double bX = ball.getX();
        double bY = ball.getY();
        double bS = ball.getScale();
        double bR = ball.getRotation();
        
        double radian = Math.toRadians(angle);
        double y = 50;
        double x = bX + bY * Math.sin(radian);
                
        double dX = (x - bX)/steps;
        double dY = (y - bY)/steps;
        double dS = (0.9 - bS)/steps;
        double dR = 360.0 / steps;
        
        for (int i = 1; i <= steps; i++) {
            ball.setScale(bS + i*dS);
            ball.setX((int) (bX + i*dX));
            ball.setY((int) (bY + i*dY));
            ball.setRotation((int) (bR + i *dR));
            pause(6);
        }
        
        // remove ring if hit
        int hitRingNumber = checkHit();
        if (hitRingNumber != -1)
            canvas.remove(ring0[hitRingNumber]);
        
        // rest ball
        ball.setScale(0.5);
        int ballX = WIDTH / 2 - (int)(ball.getWidth() * ball.getScale()) / 2;
        int ballY = HEIGHT - (int)(ball.getHeight() * ball.getScale()) - 50;
        
        ball.setX(ballX);
        ball.setY(ballY);
        //canvas.add(ball, ballX, ballY);
    }
    
    private static int checkHit() {

        int ballX = ball.getX();
        int ballY = ball.getY();
        int ballWidth = (int)(ball.getWidth() * ball.getScale());
        int ballHeight = (int)(ball.getHeight() * ball.getScale());
        int ringIndex;
        
        for(ringIndex = 0; ringIndex < ring0.length; ringIndex++) {
            
            if (hitStatus[ringIndex] == true) {
                continue;
            }
            
            int ringCenterX = ring0[ringIndex].getX() + (int)(ring0[ringIndex].getWidth()* ring0[ringIndex].getScale()) / 2;
            int ringCenterY = ring0[ringIndex].getY() + (int)(ring0[ringIndex].getHeight()* ring0[ringIndex].getScale()) / 2;
            
            if (ringCenterX > ballX &&
                ringCenterX < ballX + ballWidth &&
                ringCenterY > ballY &&
                ringCenterY < ballY + ballHeight) {
                    numberOfHitRings++;
                    hitStatus[ringIndex] = true;
                    return ringIndex;
            }
        }
        
        return -1;
    }
    
    private static boolean checkEndGame() {
    
        return numberOfHitRings == 5;
    }
    
    private static void pause(int sleepTime){
        try {
            Thread.sleep(sleepTime);
        }catch (InterruptedException e) {
            System.err.println("Error in running animation!");
            System.exit(-1);
        }
    }    
        
    public static void main(String[] args) {
        
        OlympicRings demo = new OlympicRings();
    }
    
    /**
     * Plays the animation of the five rings moving to the center and show the banner.
     */
    private static void playRingAnimation() {
        
        // remove the ball and the arrow from the canvas
        canvas.remove(arrow);
        canvas.remove(ball);
        
        // Stores the final positions of the rings to move to.
        int[][] ringsXY_positions = {   {142, 141},
                                        {400, 141},
                                        {660, 141},
                                        {271, 245},
                                        {530, 245} };
        
        // Move the 5 rings into positions of the YOG logo.
        moveRings(rings, ringsXY_positions);
        
        // Add the YOG logo for a better graphical representation.
        displayOlympicRings(OX, OY);
        
        // Remove the 5 rings from the canvas.
        for (int i=0; i<nRings; i++) {
           canvas.remove(rings[i]);
        }
           
        // Add the mooc banner on top of the logo.
        canvas.add(moocDNA, 300, 50);
    }

    public void mouseMoved(MouseEvent e){
    
        int x = e.getX();
        int y = e.getY();
        double dx = x - WIDTH / 2;
        double dy = HEIGHT - y;
        double angle = Math.toDegrees(Math.atan(dx / dy));
        arrow.setRotation((int)angle);
    }
    
    public void mousePressed(MouseEvent e){
        
        if (isShooting || !isPlaying) {
            return;
        }
    
        int x = e.getX();
        int y = e.getY();
        double dx = x - WIDTH / 2;
        double dy = HEIGHT - y;
        final double angle = Math.toDegrees(Math.atan(dx / dy));
        
        Runnable r = new Runnable()
        {
            public void run() {
                isShooting = true;
                moveBall(ball, angle);
                isShooting = false;
                
                if (checkEndGame()) {
                    isPlaying = false;
                    playRingAnimation();
                }
            }
        };      

        threadPool.execute(r);    
    }
    
    public void mouseDragged(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseClicked(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
}