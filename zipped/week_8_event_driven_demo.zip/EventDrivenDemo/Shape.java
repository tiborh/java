
/**
 * A simple Interface Demo
 * The Shape interface describes the features common to all shapes
 */
public interface Shape {
    public double area();
    public double perimeter();
}

